import RockPaperScissors from './RockPaperScissors/RockPaperScissors';

export const GAME_REGISTRY = {
  'rock-paper-scissors': RockPaperScissors,
  // 'quick-math-quiz': QuickMathQuiz,        // TODO
  // 'memory-match': MemoryMatch,             // TODO
  // 'whack-a-mole': WhackAMole,              // TODO
  // 'tic-tac-toe': TicTacToe,                // TODO
  // 'simon-says': SimonSays,                 // TODO
};
